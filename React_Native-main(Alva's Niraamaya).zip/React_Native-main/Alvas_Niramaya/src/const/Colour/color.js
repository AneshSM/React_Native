export const bgclr="#EDEDED"
export const clr60="#FFFFFF"
export const clr30="#92A65F"
export const clr10="#3C5920"
