import { View, Text } from 'react-native'
import React from 'react'

const HpmeScreen = () => {
  return (
    <View>
      <Text>HpmeScreen</Text>
    </View>
  )
}

export default HpmeScreen